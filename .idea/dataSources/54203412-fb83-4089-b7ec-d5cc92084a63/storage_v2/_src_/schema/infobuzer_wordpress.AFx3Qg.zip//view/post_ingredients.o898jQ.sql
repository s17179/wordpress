create view post_ingredients as
select `infobuzer_wordpress`.`wp_posts`.`ID`                                      AS `id`,
       group_concat(`infobuzer_wordpress`.`wp_ingredients`.`name` separator ', ') AS `ingredients`
from ((`infobuzer_wordpress`.`wp_posts` join `infobuzer_wordpress`.`wp_recipe_ingredients_items` on (
        `infobuzer_wordpress`.`wp_posts`.`ID` = `infobuzer_wordpress`.`wp_recipe_ingredients_items`.`post_id`))
         join `infobuzer_wordpress`.`wp_ingredients`
              on (`infobuzer_wordpress`.`wp_recipe_ingredients_items`.`ingredient_id` =
                  `infobuzer_wordpress`.`wp_ingredients`.`id`))
group by `infobuzer_wordpress`.`wp_posts`.`ID`;

